﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Programadores
{
    public partial class Form1 : Form
    {
        // Lista de medicamentos
        private readonly List<Medicamentos> medicamentos = new List<Medicamentos>();

        public Form1()
        {
            InitializeComponent();
            Textbox_Codigo.TabIndex = 0;
            Textbox_Nombre.TabIndex = 1;
            Textbox_Cantidad.TabIndex = 2;
            Textbox_Precio.TabIndex = 3;
            Btn_Registrar.TabIndex = 4;
            Textbox_BuscarNombre.TabIndex = 5;
            Btn_Buscar.TabIndex = 6;
            Textbox_EliminarCodigo.TabIndex = 7;
            Btn_Eliminar.TabIndex = 8;
            Btn_Ordenar.TabIndex = 9;
        }

        // metodo del boton registrar
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Si los texbox estan vacios, mostrar ventana emergente indicando que no puedes registrar vacios
            if (String.IsNullOrEmpty(Textbox_Nombre.Text) || String.IsNullOrEmpty(Textbox_Codigo.Text) || String.IsNullOrEmpty(Textbox_Cantidad.Text) || String.IsNullOrEmpty(Textbox_Precio.Text))
            {
                MessageBox.Show("Porfavor completa los campos!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                // si los textbox estan llenos agrego el nuevo medicamento y le aviso al usuario
                Medicamentos nuevoMedicamento = new Medicamentos();
                nuevoMedicamento.p_codigo = Textbox_Codigo.Text.ToUpper();
                nuevoMedicamento.p_nombre = Textbox_Nombre.Text.ToLower();
                try
                {
                    nuevoMedicamento.p_cantidad = int.Parse(Textbox_Cantidad.Text);
                    nuevoMedicamento.p_precio = double.Parse(Textbox_Precio.Text);
                }
                catch (Exception err)
                {
                    MessageBox.Show("Escribe una cantidad y precio validos!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                nuevoMedicamento.p_total = nuevoMedicamento.p_cantidad * nuevoMedicamento.p_precio;
                medicamentos.Add(nuevoMedicamento);
                MostrarMedicamentos();
                MessageBox.Show("Se registro el medicamento correctamente!","Información",MessageBoxButtons.OK,MessageBoxIcon.Information);
                Textbox_Codigo.Clear();
                Textbox_Nombre.Clear();
                Textbox_Cantidad.Clear();
                Textbox_Precio.Clear();
                Textbox_Codigo.Focus();
            }
        }

        // Metodo para mostrar en el listview los medicamentos
        private void MostrarMedicamentos()
        {
            listView1.Items.Clear();

            for (int i = 0; i < medicamentos.Count(); i++)
            {
                ListViewItem lista = new ListViewItem(medicamentos[i].p_codigo);
                lista.SubItems.Add(medicamentos[i].p_nombre);
                lista.SubItems.Add(medicamentos[i].p_cantidad.ToString());
                lista.SubItems.Add(medicamentos[i].p_precio.ToString("0.00"));
                lista.SubItems.Add(medicamentos[i].p_total.ToString("0.00"));
                listView1.Items.Add(lista);
            }
        }


        // metodo para el boton ordenar
        private void Btn_Ordenar_Click(object sender, EventArgs e)
        {
            // si la lista de medicamentos esta vacia, mostrar que no hay medicamentos registrados
            if (medicamentos.Count() == 0)
            {
                MessageBox.Show("No se registro ni un medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            } else
            {
                // si la lista tiene elementos ejecutar el metodo de ordenar con burbuja y mostrar los medicamentos actualizados(ordenados)
                OrdenarBurbuja();
                MostrarMedicamentos();
                MessageBox.Show("Medicamentos Ordenados!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // metodo burbuja llamado en el metodo del boton ordenar
        private void OrdenarBurbuja()
        {
            Medicamentos auxiliar;
            // algoritmo burbuja para ordenar alfabeticamente
            for (int i = 0; i < medicamentos.Count(); i++)
            {
                for (int j = 0; j < medicamentos.Count() - i - 1; j++)
                {
                    // compara la primera letra de cada nombre
                    if (medicamentos[j].p_nombre.First() > medicamentos[j + 1].p_nombre.First())
                    {
                        auxiliar = medicamentos[j];
                        medicamentos[j] = medicamentos[j + 1];
                        medicamentos[j + 1] = auxiliar;
                    }
                }
            }
        }

        // metodo del boton buscar
        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            // si la lista de medicamentos esta vacia, mostrar que no hay medicamentos registrados
            if (medicamentos.Count() == 0)
            {
                MessageBox.Show("No se registro ni un medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                // si la lista tiene elementos buscaremos el elemento y le avisaremos al usuario
                // metodo de busqueda secuencial
                for (int i = 0; i < medicamentos.Count(); i++)
                {
                    if (medicamentos[i].p_nombre.Equals(Textbox_BuscarNombre.Text.ToLower()))
                    {
                        MessageBox.Show("Encontrado!" + "\nCodigo: " + medicamentos[i].p_codigo + "\nNombre: " + medicamentos[i].p_nombre + "\nCantidad: " + medicamentos[i].p_cantidad + "\nPrecio: " + medicamentos[i].p_precio + "\nTotal: " + medicamentos[i].p_total, "Medicamento", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }

                MessageBox.Show("No se encontró el medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // metodo para el boton eliminar
        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            // si la lista de medicamentos esta vacia, mostrar que no hay medicamentos registrados
            if (medicamentos.Count() == 0)
            {
                MessageBox.Show("No se registro ni un medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                for (int i = 0; i < medicamentos.Count(); i++)
                {
                    // si la lista tiene elementos buscaremos el elemento a eliminar y le avisaremos al usuario
                    if (medicamentos[i].p_codigo.Equals(Textbox_EliminarCodigo.Text.ToUpper()))
                    {
                        if (MessageBox.Show("Esta seguro de eliminar?" + "\nCodigo: " + medicamentos[i].p_codigo + "\nNombre: " + medicamentos[i].p_nombre + "\nCantidad: " + medicamentos[i].p_cantidad + "\nPrecio: " + medicamentos[i].p_precio + "\nTotal: " + medicamentos[i].p_total, "Medicamento", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                        {
                            medicamentos.Remove(medicamentos[i]);
                            MostrarMedicamentos();
                            MessageBox.Show("Eliminado correctamente!", "Información", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        return;
                    }
                }

                MessageBox.Show("No se encontró el medicamento!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
