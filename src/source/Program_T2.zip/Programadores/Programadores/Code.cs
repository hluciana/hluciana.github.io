﻿using System;

// Espacio de nombre Programadores
namespace Programadores
{
    // Creando una estructura de Medicamentos
    public struct Medicamentos
    {
        // Creo variables publicas accesibles y modificables de los medicamentos como nombre,codigo,cantidad,etc
        public string p_codigo, p_nombre;
        public int p_cantidad;
        public double p_precio;
        public double p_total;
    }
}
