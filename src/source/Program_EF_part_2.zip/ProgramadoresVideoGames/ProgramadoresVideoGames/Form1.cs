﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace ProgramadoresVideoGames
{
    public partial class Form1 : Form
    {
        // Lista para guardar todo el registro de los videojuegos agregados
        private readonly List<VideoJuegos> registroJuegos = new List<VideoJuegos>();
        private string ubicacion = String.Empty;
        private int puntosTotales = 0;

        public Form1()
        {
            InitializeComponent();
            Combobox_Dia.DropDownStyle = ComboBoxStyle.DropDownList;
            Combobox_Dia.Text = "Lunes";
            Lbl_Total.Text = "";
            Btn_Guardar.Enabled = false;
        }

        // Método del boton registrar donde se motrará y guardara toda la informacion(juegos,días,resultado,puntos)
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Comprobamos si el textbox de juegos esta vacío
            if (String.IsNullOrEmpty(Textbox_juegos.Text))
            {
                MessageBox.Show("Porfavor escribe un juego!","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            } else
            {
                // En caso el textbox este completo verificamos si uno de los checkbox esta seleccionado
                if (Check_Victoria.Checked == false && Check_Derrota.Checked == false)
                {
                    MessageBox.Show("Porfavor seleccione su resultado!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                } else
                {
                    // Si todo esta correcto agregamos puntos y registramos el nuevo juego
                    if (Check_Victoria.Checked == true)
                    {
                        puntosTotales += 100;
                        Registro("Victoria",100);
                    }
                    else
                    {
                        puntosTotales -= 20;
                        Registro("Derrota",-20);
                    }
                }
            }
        }

        // Método para mostrar y registrar un nuevo juego una vez verificado que todo este correcto
        private void Registro(string resultado,int puntos)
        {
            VideoJuegos nuevoJuego = new VideoJuegos();
            nuevoJuego.p_dia = Combobox_Dia.Text;
            nuevoJuego.p_juego = Textbox_juegos.Text;
            nuevoJuego.p_resultado = resultado;
            nuevoJuego.p_puntos = puntos;
            nuevoJuego.p_total = puntosTotales;

            registroJuegos.Add(nuevoJuego);

            ListViewItem fila = new ListViewItem(nuevoJuego.p_dia);
            fila.SubItems.Add(nuevoJuego.p_juego);
            fila.SubItems.Add(nuevoJuego.p_resultado);
            fila.SubItems.Add(nuevoJuego.p_puntos.ToString());
            listView1.Items.Add(fila);

            Lbl_Total.Text = puntosTotales.ToString();

            if (resultado == "Victoria") Check_Victoria.Checked = false;
            else Check_Derrota.Checked = false;
            Textbox_juegos.Clear();
            Textbox_juegos.Focus();
        }

        // Método del checkbox victoria
        private void Check_Victoria_CheckedChanged(object sender, EventArgs e)
        {
            if (Check_Victoria.Checked == true) Check_Derrota.Enabled = false;
            else Check_Derrota.Enabled = true;
        }

        // Método del checkbox derrota
        private void Check_Derrota_CheckedChanged(object sender, EventArgs e)
        {
            if (Check_Derrota.Checked == true) Check_Victoria.Enabled = false;
            else Check_Victoria.Enabled = true;
        }

        // Método del botón seleccionar ubicación que nos servira para guardar la informacion en bloc de notas(txt)
        private void Btn_Ubicacion_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog ruta = new FolderBrowserDialog();

            if (ruta.ShowDialog() == DialogResult.OK)
            {
                ubicacion = ruta.SelectedPath;
                Btn_Guardar.Enabled = true;
            }
        }

        // Método del boton guardar
        private void Btn_Guardar_Click(object sender, EventArgs e)
        {
            // Comprobamos que se haya registrado al menos un juego para guardar en txt
            if (registroJuegos.Count() == 0)
            {
                MessageBox.Show("Debes registrar al menos 1 juego!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Si esta todo correcto le avisamos al usuario para guardar
                if (MessageBox.Show("Estas seguro que quieres guardarlo?" + "\n" + "Ubicación: " + ubicacion, "Info", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    string guardar = ubicacion + "\\" + "base_de_informacion.txt";

                    using (StreamWriter archivo = new StreamWriter(guardar))
                    {
                        archivo.WriteLine("***** REGISTRO VIDEOJUEGOS ******");
                        for (int i = 0;i < registroJuegos.Count(); i++)
                        {
                            archivo.WriteLine("\nRegistro " + (i + 1) + ": ");
                            archivo.WriteLine("Dia: " + registroJuegos[i].p_dia);
                            archivo.WriteLine("Juego: " + registroJuegos[i].p_juego);
                            archivo.WriteLine("Resultado: " + registroJuegos[i].p_resultado);
                            archivo.WriteLine("Puntos obtenidos: " + registroJuegos[i].p_puntos);
                            archivo.WriteLine("Puntos totales: " + registroJuegos[i].p_total);
                            archivo.WriteLine("\n-------------------------------");
                        }
                    }
                }
            }
        }
    }
}
