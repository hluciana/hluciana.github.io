﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramadoresVideoGames
{
    // Clase videojuegos que nos ayudara para mantener un registro

    public class VideoJuegos
    {
        // Sus respectivas variables para leer y modificar
        public string p_dia;
        public string p_juego;
        public string p_resultado;
        public int p_puntos;
        public int p_total;
    }
}
