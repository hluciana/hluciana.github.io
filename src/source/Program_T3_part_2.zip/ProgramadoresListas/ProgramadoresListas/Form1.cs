﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace ProgramadoresListas
{
    public partial class Form1 : Form
    {
        // Lista de lo numeros que agregara el usuario
        private readonly List<int> listaNumeros = new List<int>();

        public Form1()
        {
            InitializeComponent();
            Textbox_Ingresar.Clear();
        }

        // Método del botón insertar
        private void Btn_Insertar_Click(object sender, EventArgs e)
        {
            // Reviso que el textbox no este vacío
            if (String.IsNullOrEmpty(Textbox_Ingresar.Text))
            {
                MessageBox.Show("Completa el campo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                // En caso este lleno guardamos los numeros 
                listaNumeros.Clear();
                Richtextbox_Salida.Clear();

                List<string> lista = Textbox_Ingresar.Text.Split(',').ToList();

                try
                {
                    for (int i = 0; i < lista.Count(); i++)
                    {
                        listaNumeros.Add(int.Parse(lista[i]));
                    }
                } catch(Exception err)
                {
                    MessageBox.Show("Revisa que hayas puesto los datos correctamente!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                MostrarElementos();
                Textbox_Ingresar.Clear();
            }
        }

        // Método del boton ordenar ascendentemente
        private void Btn_OrdenA_Click(object sender, EventArgs e)
        {
            // Compruebo que la lista no este vacia para ordenar
            if (listaNumeros.Count() == 0)
            {
                MessageBox.Show("Debes insertar numeros para ordenar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Si la lista tiene elementos se ordenara 
                Richtextbox_Salida.Clear();
                listaNumeros.Sort();
                MostrarElementos();
            }
        }

        // Método del boton ordenar descendentemente
        private void Btn_OrdenD_Click(object sender, EventArgs e)
        {
            // Compruebo que la lista no este vacia para ordenar
            if (listaNumeros.Count() == 0)
            {
                MessageBox.Show("Debes insertar numeros para ordenar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Si la lista tiene elementos se ordenara
                Richtextbox_Salida.Clear();
                listaNumeros.Sort((a, b) => b.CompareTo(a));
                MostrarElementos();
            }
        }

        // Método del boton buscar
        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            // Compruebo que la lista no este vacía antes de hacer la búsqueda
            if (listaNumeros.Count() == 0)
            {
                MessageBox.Show("Debes insertar numeros para buscar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Compruebo que el textbox no este vacío
                if (String.IsNullOrEmpty(Textbox_Buscar.Text))
                {
                    MessageBox.Show("Porfavor completa el campo!", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
                else
                {
                    // Llamo al método de buscar pasandole el indice y el número a buscar
                    try
                    {
                        if (BusquedaRecursiva(int.Parse(Textbox_Buscar.Text), 0))
                        {
                            MessageBox.Show("El número fue encontrado!", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("El numero ingresado no se encontro!", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch(Exception err)
                    {
                        MessageBox.Show("Formato invalido!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
            }
        }

        // Método que hara una búsqueda secuencial usando recursividad
        private bool BusquedaRecursiva(int numero, int i)
        {
            if (i < listaNumeros.Count())
            {
                if (listaNumeros[i] == numero) return true;
                else return BusquedaRecursiva(numero, i + 1);
            }
            return false;
        }

        // Método del boton eliminar
        private void Btn_Eliminar_Click(object sender, EventArgs e)
        {
            // Comprobamos que haya numeros en la lista para eliminar
            if (listaNumeros.Count() == 0)
            {
                MessageBox.Show("Debes insertar numeros para eliminar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Comprobamos que la caja no este vacía 
                if (String.IsNullOrEmpty(Textbox_Eliminar.Text))
                {
                    MessageBox.Show("Porfavor completa el campo!", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
                else
                {
                    // Llamo al método de eliminar pasandole el indice y el número a buscar
                    try
                    {
                        if (EliminarRecursivo(int.Parse(Textbox_Eliminar.Text), 0))
                        {
                            MessageBox.Show("El número fue encontrado y eliminado", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("No se pudo eliminar ya que no fue encontrado el número", "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Formato invalido!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    Richtextbox_Salida.Clear();
                    MostrarElementos();
                }
            }
        }

        // Método que elimina un número usando recursividad
        private bool EliminarRecursivo(int num2,int j)
        {
            if (j < listaNumeros.Count())
            {
                if (listaNumeros[j] == num2)
                {
                    listaNumeros.Remove(listaNumeros[j]);
                    return true;
                }
                else
                {
                    return EliminarRecursivo(num2, j + 1);
                }
            }
            return false;
        }


        // Método que mostrará los elementos de la lista en el textbox salida
        private void MostrarElementos()
        {
            for (int i = 0; i < listaNumeros.Count(); i++)
            {
                Richtextbox_Salida.Text += listaNumeros[i] + " ";
            }
        }
    }
}
