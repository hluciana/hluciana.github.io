﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Programadores
{
    public partial class Form1 : Form
    {
        // Listas de los dueños y mascotas
        private readonly List<Duenos> registroDuenos = new List<Duenos>();
        private readonly List<Mascotas> registroMascotas = new List<Mascotas>();

        public Form1()
        {
            InitializeComponent();
            ComboBox_DuenoM.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        // Método del boton registrar Dueños
        private void Btn_RegistrarDueno_Click(object sender, EventArgs e)
        {
            // Comprobamos que los textbox no se encuentren vacios
            if (String.IsNullOrEmpty(Textbox_NombreD.Text) || String.IsNullOrEmpty(Textbox_DireccionD.Text) || String.IsNullOrEmpty(Textbox_TelefonoD.Text))
            {
                MessageBox.Show("Completa todos los campos!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Si todos los campos estan completos registramos nuevo dueño
                Duenos nuevoDueno = new Duenos();
                nuevoDueno.p_nombreD = Textbox_NombreD.Text;
                nuevoDueno.p_direccionD = Textbox_DireccionD.Text;

                try
                {
                    nuevoDueno.p_telefonoD = int.Parse(Textbox_TelefonoD.Text);
                    if (Textbox_TelefonoD.Text.Length != 9) throw new Exception();
                }
                catch(Exception err)
                {
                    MessageBox.Show("Ingresa un telefono valido(9 digitos)!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                registroDuenos.Add(nuevoDueno);

                ListViewItem fila = new ListViewItem(nuevoDueno.p_nombreD);
                fila.SubItems.Add(nuevoDueno.p_direccionD);
                fila.SubItems.Add(nuevoDueno.p_telefonoD.ToString());
                listView1.Items.Add(fila);

                ComboBox_DuenoM.Items.Add(nuevoDueno.p_nombreD);
                ComboBox_DuenoM.Text = nuevoDueno.p_nombreD;

                Textbox_NombreD.Clear();
                Textbox_DireccionD.Clear();
                Textbox_TelefonoD.Clear();
            }
        }

        private void Btn_RegistrarMascota_Click(object sender, EventArgs e)
        {
            // Comprobamos que los textbox no se encuentren vacios
            if (String.IsNullOrEmpty(Textbox_NombreM.Text) || String.IsNullOrEmpty(Textbox_EdadM.Text) || String.IsNullOrEmpty(Textbox_RazaM.Text) || String.IsNullOrEmpty(ComboBox_DuenoM.Text))
            {
                MessageBox.Show("Los campos no pueden estar vacios!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // En caso este completo agregamos una nueva mascota
                Mascotas nuevaMascota = new Mascotas();
                nuevaMascota.p_duenoM = ComboBox_DuenoM.Text;
                nuevaMascota.p_nombreM = Textbox_NombreM.Text;
                try
                {
                    nuevaMascota.p_edadM = int.Parse(Textbox_EdadM.Text);
                }
                catch (Exception err)
                {
                    MessageBox.Show("Ingresa una edad valida!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                nuevaMascota.p_RazaM = Textbox_RazaM.Text;

                registroMascotas.Add(nuevaMascota);

                ListViewItem fila2 = new ListViewItem(nuevaMascota.p_duenoM);
                fila2.SubItems.Add(nuevaMascota.p_nombreM);
                fila2.SubItems.Add(nuevaMascota.p_edadM.ToString());
                fila2.SubItems.Add(nuevaMascota.p_RazaM);
                listView2.Items.Add(fila2);

                Textbox_NombreM.Clear();
                Textbox_EdadM.Clear();
                Textbox_RazaM.Clear();
            }
        }

        // Método del boton buscar
        private void Btn_Buscar_Click(object sender, EventArgs e)
        {
            // Comprobamos que haya registrado al menos una mascota
            if (registroMascotas.Count() == 0)
            {
                MessageBox.Show("Debes registrar mascotas para buscar!", "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                // Comprobamos que el textbox no este vacío para poder buscar
                if (String.IsNullOrEmpty(Textbox_BuscarM.Text))
                {
                    MessageBox.Show("Porfavor completa el campo!", "Ayuda", MessageBoxButtons.OK, MessageBoxIcon.Question);
                }
                else
                {
                    MessageBox.Show(BusquedaRecursiva(Textbox_BuscarM.Text, 0), "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        // Creo un método que hara una búsqueda secuencial usando recursividad
        private string BusquedaRecursiva(string mascota, int i)
        {
            if (i < registroMascotas.Count())
            {
                if (registroMascotas[i].p_nombreM.ToLower() == mascota.ToLower())
                {
                    return "Mascota encontrada!" + "\nDueño: " + registroMascotas[i].p_duenoM + "\nNombre: " + registroMascotas[i].p_nombreM + "\nEdad: " + registroMascotas[i].p_edadM + "\nRaza: " + registroMascotas[i].p_RazaM;
                }
                else
                {
                    return BusquedaRecursiva(mascota, i + 1);
                }
            }
            return "La mascota no esta registrada!";
        }
    }
}
