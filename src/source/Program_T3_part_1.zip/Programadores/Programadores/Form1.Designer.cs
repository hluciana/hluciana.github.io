﻿namespace Programadores
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.Column_Nombre = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Column_Direccion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Column_Telefono = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Btn_RegistrarDueno = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Textbox_TelefonoD = new System.Windows.Forms.TextBox();
            this.Textbox_DireccionD = new System.Windows.Forms.TextBox();
            this.Textbox_NombreD = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Textbox_BuscarM = new System.Windows.Forms.TextBox();
            this.Btn_Buscar = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.listView2 = new System.Windows.Forms.ListView();
            this.Column_Dueño = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Column_NombreMas = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Column_Edad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Column_Raza = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ComboBox_DuenoM = new System.Windows.Forms.ComboBox();
            this.Btn_RegistrarMascota = new System.Windows.Forms.Button();
            this.Textbox_RazaM = new System.Windows.Forms.TextBox();
            this.Textbox_EdadM = new System.Windows.Forms.TextBox();
            this.Textbox_NombreM = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(21, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(755, 414);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(747, 381);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Registro dueños";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Salmon;
            this.groupBox2.Controls.Add(this.listView1);
            this.groupBox2.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(172, 216);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(447, 157);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lista:";
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.listView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Column_Nombre,
            this.Column_Direccion,
            this.Column_Telefono});
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(6, 29);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(435, 109);
            this.listView1.TabIndex = 0;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // Column_Nombre
            // 
            this.Column_Nombre.Text = "Nombre:";
            this.Column_Nombre.Width = 143;
            // 
            // Column_Direccion
            // 
            this.Column_Direccion.Text = "Dirección:";
            this.Column_Direccion.Width = 143;
            // 
            // Column_Telefono
            // 
            this.Column_Telefono.Text = "Telefono:";
            this.Column_Telefono.Width = 140;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.PaleGreen;
            this.groupBox1.Controls.Add(this.Btn_RegistrarDueno);
            this.groupBox1.Controls.Add(this.pictureBox1);
            this.groupBox1.Controls.Add(this.Textbox_TelefonoD);
            this.groupBox1.Controls.Add(this.Textbox_DireccionD);
            this.groupBox1.Controls.Add(this.Textbox_NombreD);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Cursor = System.Windows.Forms.Cursors.Default;
            this.groupBox1.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox1.Location = new System.Drawing.Point(172, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(447, 204);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos:";
            // 
            // Btn_RegistrarDueno
            // 
            this.Btn_RegistrarDueno.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_RegistrarDueno.Location = new System.Drawing.Point(25, 166);
            this.Btn_RegistrarDueno.Name = "Btn_RegistrarDueno";
            this.Btn_RegistrarDueno.Size = new System.Drawing.Size(221, 23);
            this.Btn_RegistrarDueno.TabIndex = 7;
            this.Btn_RegistrarDueno.Text = "Registrar";
            this.Btn_RegistrarDueno.UseVisualStyleBackColor = true;
            this.Btn_RegistrarDueno.Click += new System.EventHandler(this.Btn_RegistrarDueno_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(280, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(145, 170);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Textbox_TelefonoD
            // 
            this.Textbox_TelefonoD.Location = new System.Drawing.Point(120, 119);
            this.Textbox_TelefonoD.Name = "Textbox_TelefonoD";
            this.Textbox_TelefonoD.Size = new System.Drawing.Size(126, 20);
            this.Textbox_TelefonoD.TabIndex = 5;
            // 
            // Textbox_DireccionD
            // 
            this.Textbox_DireccionD.Location = new System.Drawing.Point(120, 78);
            this.Textbox_DireccionD.Name = "Textbox_DireccionD";
            this.Textbox_DireccionD.Size = new System.Drawing.Size(126, 20);
            this.Textbox_DireccionD.TabIndex = 4;
            // 
            // Textbox_NombreD
            // 
            this.Textbox_NombreD.Location = new System.Drawing.Point(120, 32);
            this.Textbox_NombreD.Name = "Textbox_NombreD";
            this.Textbox_NombreD.Size = new System.Drawing.Size(126, 20);
            this.Textbox_NombreD.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(21, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 19);
            this.label3.TabIndex = 2;
            this.label3.Text = "Teléfono:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(24, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 19);
            this.label2.TabIndex = 1;
            this.label2.Text = "Dirección:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(24, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightGray;
            this.tabPage2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage2.Controls.Add(this.panel1);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Cursor = System.Windows.Forms.Cursors.Default;
            this.tabPage2.ForeColor = System.Drawing.SystemColors.Desktop;
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(747, 381);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Registro mascotas";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.IndianRed;
            this.panel1.Controls.Add(this.Textbox_BuscarM);
            this.panel1.Controls.Add(this.Btn_Buscar);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Location = new System.Drawing.Point(497, 110);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(206, 178);
            this.panel1.TabIndex = 2;
            // 
            // Textbox_BuscarM
            // 
            this.Textbox_BuscarM.Location = new System.Drawing.Point(26, 80);
            this.Textbox_BuscarM.Name = "Textbox_BuscarM";
            this.Textbox_BuscarM.Size = new System.Drawing.Size(157, 26);
            this.Textbox_BuscarM.TabIndex = 2;
            // 
            // Btn_Buscar
            // 
            this.Btn_Buscar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_Buscar.Location = new System.Drawing.Point(26, 129);
            this.Btn_Buscar.Name = "Btn_Buscar";
            this.Btn_Buscar.Size = new System.Drawing.Size(157, 30);
            this.Btn_Buscar.TabIndex = 1;
            this.Btn_Buscar.Text = "Buscar";
            this.Btn_Buscar.UseVisualStyleBackColor = true;
            this.Btn_Buscar.Click += new System.EventHandler(this.Btn_Buscar_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(161, 22);
            this.label8.TabIndex = 0;
            this.label8.Text = "Buscar Mascota";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(130)))), ((int)(((byte)(0)))));
            this.groupBox4.Controls.Add(this.listView2);
            this.groupBox4.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(44, 239);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(438, 134);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Lista:";
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.Wheat;
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Column_Dueño,
            this.Column_NombreMas,
            this.Column_Edad,
            this.Column_Raza});
            this.listView2.HideSelection = false;
            this.listView2.Location = new System.Drawing.Point(6, 28);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(426, 89);
            this.listView2.TabIndex = 0;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // Column_Dueño
            // 
            this.Column_Dueño.Text = "Dueño:";
            this.Column_Dueño.Width = 102;
            // 
            // Column_NombreMas
            // 
            this.Column_NombreMas.Text = "Nombre:";
            this.Column_NombreMas.Width = 105;
            // 
            // Column_Edad
            // 
            this.Column_Edad.Text = "Edad:";
            this.Column_Edad.Width = 103;
            // 
            // Column_Raza
            // 
            this.Column_Raza.Text = "Raza:";
            this.Column_Raza.Width = 110;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.RosyBrown;
            this.groupBox3.Controls.Add(this.ComboBox_DuenoM);
            this.groupBox3.Controls.Add(this.Btn_RegistrarMascota);
            this.groupBox3.Controls.Add(this.Textbox_RazaM);
            this.groupBox3.Controls.Add(this.Textbox_EdadM);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.Textbox_NombreM);
            this.groupBox3.Controls.Add(this.label6);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Controls.Add(this.pictureBox2);
            this.groupBox3.Font = new System.Drawing.Font("Arial", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(44, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(438, 227);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Info:";
            // 
            // ComboBox_DuenoM
            // 
            this.ComboBox_DuenoM.FormattingEnabled = true;
            this.ComboBox_DuenoM.Location = new System.Drawing.Point(108, 29);
            this.ComboBox_DuenoM.Name = "ComboBox_DuenoM";
            this.ComboBox_DuenoM.Size = new System.Drawing.Size(123, 22);
            this.ComboBox_DuenoM.TabIndex = 10;
            // 
            // Btn_RegistrarMascota
            // 
            this.Btn_RegistrarMascota.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Btn_RegistrarMascota.Location = new System.Drawing.Point(25, 184);
            this.Btn_RegistrarMascota.Name = "Btn_RegistrarMascota";
            this.Btn_RegistrarMascota.Size = new System.Drawing.Size(206, 23);
            this.Btn_RegistrarMascota.TabIndex = 9;
            this.Btn_RegistrarMascota.Text = "Registrar";
            this.Btn_RegistrarMascota.UseVisualStyleBackColor = true;
            this.Btn_RegistrarMascota.Click += new System.EventHandler(this.Btn_RegistrarMascota_Click);
            // 
            // Textbox_RazaM
            // 
            this.Textbox_RazaM.Location = new System.Drawing.Point(108, 141);
            this.Textbox_RazaM.Name = "Textbox_RazaM";
            this.Textbox_RazaM.Size = new System.Drawing.Size(123, 20);
            this.Textbox_RazaM.TabIndex = 7;
            // 
            // Textbox_EdadM
            // 
            this.Textbox_EdadM.Location = new System.Drawing.Point(108, 103);
            this.Textbox_EdadM.Name = "Textbox_EdadM";
            this.Textbox_EdadM.Size = new System.Drawing.Size(123, 20);
            this.Textbox_EdadM.TabIndex = 6;
            // 
            // Textbox_NombreM
            // 
            this.Textbox_NombreM.Location = new System.Drawing.Point(108, 65);
            this.Textbox_NombreM.Name = "Textbox_NombreM";
            this.Textbox_NombreM.Size = new System.Drawing.Size(123, 20);
            this.Textbox_NombreM.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(21, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 19);
            this.label7.TabIndex = 4;
            this.label7.Text = "Dueño:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(21, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 19);
            this.label6.TabIndex = 3;
            this.label6.Text = "Raza:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(21, 102);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(47, 19);
            this.label5.TabIndex = 2;
            this.label5.Text = "Edad:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(21, 65);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(69, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "Nombre:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(251, 29);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(164, 178);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Refugio de Animales";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button Btn_RegistrarDueno;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox Textbox_TelefonoD;
        private System.Windows.Forms.TextBox Textbox_DireccionD;
        private System.Windows.Forms.TextBox Textbox_NombreD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader Column_Nombre;
        private System.Windows.Forms.ColumnHeader Column_Direccion;
        private System.Windows.Forms.ColumnHeader Column_Telefono;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox Textbox_BuscarM;
        private System.Windows.Forms.Button Btn_Buscar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader Column_Dueño;
        private System.Windows.Forms.ColumnHeader Column_NombreMas;
        private System.Windows.Forms.ColumnHeader Column_Edad;
        private System.Windows.Forms.ColumnHeader Column_Raza;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox ComboBox_DuenoM;
        private System.Windows.Forms.Button Btn_RegistrarMascota;
        private System.Windows.Forms.TextBox Textbox_RazaM;
        private System.Windows.Forms.TextBox Textbox_EdadM;
        private System.Windows.Forms.TextBox Textbox_NombreM;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}

