﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Usando un nombre de espacios llamado Programadores
namespace Programadores
{
    // Creo dos clases publicas Dueños y Mascotas que tendrán sus respectivos datos
    public class Duenos
    {
        public string p_nombreD;
        public string p_direccionD;
        public int p_telefonoD;
    }

    public class Mascotas
    {
        public string p_duenoM;
        public string p_nombreM;
        public int p_edadM;
        public string p_RazaM;
    }
}
