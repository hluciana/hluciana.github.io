﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace ProgramadoresArrays
{
    public partial class Form1 : Form
    {
        // arreglo de los textos que se agregaran
        private string[] arregloTexto;
        private int indice = 0;

        public Form1()
        {
            InitializeComponent();
            Textbox_Cantidad.TabIndex = 0;
            Btn_Cantidad.TabIndex = 1;
            Textbox_Registrar.TabIndex = 2;
            Btn_Registrar.TabIndex = 3;
            Btn_Ordenar.TabIndex = 4;
            Textbox_Registrar.Enabled = false;
            Btn_Registrar.Enabled = false;
            Btn_Ordenar.Enabled = false;
            Richtextbox_Mostrar.Enabled = false;
        }

        // Método del boton aceptar(tamaño)
        private void Btn_Cantidad_Click(object sender, EventArgs e)
        {
            // Comprobamos si el textbox esta vacio
            if (String.IsNullOrEmpty(Textbox_Cantidad.Text))
            {
                MessageBox.Show("Porfavor completa el campo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                // Si esta lleno el textbox le asignamos el tamaño elegido al arreglo y le habilitamos que pueda agregar contenido
                try
                {
                    arregloTexto = new string[int.Parse(Textbox_Cantidad.Text)];
                    if (arregloTexto.Length == 0) throw new Exception();
                }
                catch (Exception err)
                {
                    MessageBox.Show("Ingresa un valor valido!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                Textbox_Cantidad.Enabled = false;
                Btn_Cantidad.Enabled = false;
                Textbox_Registrar.Enabled = true;
                Btn_Registrar.Enabled = true;
                Btn_Ordenar.Enabled = true;
                Richtextbox_Mostrar.Enabled = true;
                Textbox_Registrar.Focus();
            }
        }

        // Método del boton aceptar(texto)
        private void Btn_Registrar_Click(object sender, EventArgs e)
        {
            // Comprobamos si el textbox esta vacio
            if (String.IsNullOrEmpty(Textbox_Registrar.Text))
            {
                MessageBox.Show("Porfavor completa el campo!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else
            {
                // Si esta lleno el textbox agregamos el contenido a nuestro arreglo
                arregloTexto[indice] = Textbox_Registrar.Text.ToLower();
                indice++;
                if(indice == arregloTexto.Length)
                {
                    Textbox_Registrar.Enabled = false;
                    Btn_Registrar.Enabled = false;
                }
                Mostrar();
                Textbox_Registrar.Clear();
                Textbox_Registrar.Focus();
            }
        }

        // Método del botón ordenar
        private void Btn_Ordenar_Click(object sender, EventArgs e)
        {
            MessageBox.Show(OrdenRecursivo(0, indice), "Informacion", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Mostrar();
        }

        // Este es la primera parte del algoritmo del método burbuja
        private string OrdenRecursivo(int i, int limite)
        {
            if (i < limite)
            {
                Recorrer(0, limite, i);
                return OrdenRecursivo(i + 1, limite);
            }
            return "Se ordeno el arreglo correctamente!";
        }

        // Esta es la segunda parte del método burbuja recursivo
        private void Recorrer(int j,int limite2, int res)
        {
            string auxiliar;
            if (j < limite2 - res - 1)
            {
                if (arregloTexto[j + 1].First() < arregloTexto[j].First())
                {
                    auxiliar = arregloTexto[j];
                    arregloTexto[j] = arregloTexto[j + 1];
                    arregloTexto[j + 1] = auxiliar;
                }
                Recorrer(j + 1, limite2, res);
            }
        }

        // Método para mostrar los elementos en el richtextbox
        private void Mostrar()
        {
            Richtextbox_Mostrar.Clear();
            for (int i = 0; i < indice; i++)
            {
                Richtextbox_Mostrar.Text += arregloTexto[i] + "\n";
            }
        }
    }
}
